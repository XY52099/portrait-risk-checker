const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024 },
  fileFilter: (req,file,cb) => {
    if (/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) cb(null,true);
    else cb(new Error("只支持 JPG、PNG、WEBP、GIF 图片"));
  }
});

app.use(express.static(path.join(__dirname,"public")));
app.use(express.json({limit:"1mb"}));

function extractText(data){
  if (!data) return "";
  const c = data.choices?.[0]?.message?.content;
  if (typeof c === "string") return c;
  if (Array.isArray(c)) return c.map(x=>x.text||"").join("");
  return "";
}
function safeJson(text){
  try { return JSON.parse(text); } catch {}
  const m = text.match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch {} }
  return null;
}

app.post("/api/analyze", upload.single("image"), async (req,res)=>{
  try{
    if(!req.file) return res.status(400).json({error:"请选择图片"});
    const {VISION_API_URL, VISION_API_KEY, VISION_MODEL} = process.env;
    if(!VISION_API_URL || !VISION_API_KEY || !VISION_MODEL)
      return res.status(500).json({error:"服务器尚未配置视觉模型。请填写 .env 中的 VISION_API_URL、VISION_API_KEY、VISION_MODEL。"});

    const base64 = req.file.buffer.toString("base64");
    const prompt = `你是“素材提交前合规预检器”。请分析这张图片，但不要声称能确定版权归属，也不要把结果描述成任何平台审核结果。
重点判断：
1. 是否存在真人脸/人物，数量和大致置信度；
2. 是否存在明显肖像权风险（真人、清晰正脸、疑似公众人物等；不能仅凭照片断言身份）；
3. 是否存在明显IP/版权风险（影视、动漫、游戏角色、摄影作品、品牌Logo等视觉线索）；
4. 是否存在水印、署名或平台标记；
5. 是否建议提交前进一步确认授权。
严格只返回 JSON，不要 Markdown：
{
 "overall_score": 0-100,
 "level": "低风险|需确认|高风险",
 "face": {"detected": true/false, "count": 0, "confidence": 0-100},
 "portrait_risk": {"score":0-100,"reason":"..."},
 "copyright_risk": {"score":0-100,"reason":"..."},
 "ip_signals":["..."],
 "watermark_signals":["..."],
 "advice":["..."],
 "limitations":["版权归属和授权不能仅凭图片确认","本结果不是任何平台审核结果"]
}
不要识别或输出个人敏感身份信息。`;

    const body = {
      model: VISION_MODEL,
      messages: [{
        role:"user",
        content:[
          {type:"text",text:prompt},
          {type:"image_url",image_url:{url:`data:${req.file.mimetype};base64,${base64}`}}
        ]
      }],
      temperature:0.1
    };

    const r = await fetch(VISION_API_URL,{
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${VISION_API_KEY}`},
      body:JSON.stringify(body)
    });
    const raw = await r.text();
    if(!r.ok) return res.status(502).json({error:"视觉模型调用失败",detail:raw.slice(0,1000)});
    const data = JSON.parse(raw);
    const parsed = safeJson(extractText(data));
    if(!parsed) return res.status(502).json({error:"模型返回格式无法解析",raw:extractText(data).slice(0,2000)});
    res.json(parsed);
  }catch(e){
    res.status(500).json({error:e.message||"检测失败"});
  }
});

app.use((err,req,res,next)=>{
  res.status(400).json({error:err.message||"请求失败"});
});
app.listen(PORT,()=>console.log(`Portrait Risk Checker: http://localhost:${PORT}`));
